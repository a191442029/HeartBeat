[session_id: 6ab0dc711459f334599eadb3 | topic_summary_time: 2026-09-23 19:06:44]用户评估并确认在EXE的BLE扫描功能中显示蓝牙信号强度（RSSI），要求改动后直接构建EXE。助理通过联网查证RSSI定义及范围，确认BLE广播包自带该值，无需连接设备即可获取。

---

助理修改Blegetheartbeat.py，使用BleakScanner.discover(return_adv=True)获取RSSI，实现同设备跨扫描均值平滑及按信号强度排序；修改DevCtrl.py在设备列表行显示RSSI值（如“-47 dBm ▂▄▆█ 优秀”）及分级图标，分级标准为≤-50 dBm优秀、-51~-65 dBm良好、-66~-80 dBm一般、<-80 dBm较弱。版本号更新至v1.0.9并启动构建。

---

用户遇到连接错误[WinError -2147418113]（E_UNEXPECTED），助理解释这是Windows蓝牙栈内部失败，常见于设备不可达、适配器状态切换或WinRT会话问题，与信号弱无直接关系但可能间接诱发。建议用户通过v1.0.9新增的RSSI显示判断信号强度（-70以上正常，-80以下需调整设备位置），并确认手环是否被手机占用。
